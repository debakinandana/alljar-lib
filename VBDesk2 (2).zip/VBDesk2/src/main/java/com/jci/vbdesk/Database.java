package com.jci.vbdesk;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jci.vbdesk.model.Order;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;


public class Database {

	private static Database instance = new Database();

	public static Database getInstance() {
		return instance;
	}
	
	/*private MongoClient mongoClient = new MongoClient(new MongoClientURI(
			"mongodb://vbdesk-demo:lDdJVdQUmcwIMnzSSrrgjsgRUvtWTByFonS9ILMD49o2ZZj9OSvNJmbh1P7YY6WM5rayz2qIK9wzFTxt6iVwpQ==@vbdesk-demo.documents.azure.com:10255/?ssl=true&replicaSet=globaldb"));
*/
 
	
	private MongoClient mongoClient = new MongoClient("127.0.0.1");

	private MongoDatabase database = mongoClient.getDatabase("VBDesk");

	private MongoCollection<Document> collection = database.getCollection("Orders");
	
	public JSONObject getOrder(String id) {
		System.out.println("Get Order By Id method......");
		Bson filter = Filters.eq("_id", id);
		JSONArray array = new JSONArray();
		collection.find(filter).forEach(new Block<Document>() {
			@Override
			public void apply(Document orderDoc) {
				System.out.println("Printing OrderDoc from Get Order Method ::"+orderDoc);
				JSONObject orderJson = new JSONObject(orderDoc.toJson());
				String id = orderJson.getString("_id");
				orderJson.remove("_id");
				orderJson.put("id", id);
				array.put(orderJson);
				System.out.println("Printing OrderJSON from Get Order Method ::"+orderJson);
			}
			
		});
		return array.length() != 0 ? array.getJSONObject(0) : null;
	}
	
/*	public JSONArray getOrderByFilters(String customernumber,String ordernumber, String ponumber, String assignee, Date creationdatefrom, Date creationdateto,
			Date requesteddelivdatefrom, Date requesteddelivdateto, Date expecteddelivdatefrom, Date expecteddelivdateto, 
			Date confirmeddelivdatefrom, Date confirmeddelivdateto, Date actualdelivdatefrom, Date actualdelivdateto,
			String orderstatus, String customeruser) {*/
		
		public JSONArray getOrderByFilters(String customername, String ordernumber, String ponumber, String assignee,
				String creationdatefrom, String creationdateto,
				String requestedshipdatefrom, String requestedshipdateto,
				String expectedshipdatefrom, String expectedshipdateto,
				String confirmedshipdatefrom, String confirmedshipdateto,
				String actualshipdatefrom, String actualshipdateto,
				String orderstatus, String customeruser) {
		
			
		List<Bson> filters = new ArrayList<>();

		
		if (StringUtils.isNotBlank(customername)) {
		
			filters.add(Filters.regex("customer_name", customername));
			System.out.println("customer_name ::"+customername);
		}
		if (StringUtils.isNotBlank(ordernumber)) {
			filters.add(Filters.regex("order_number", ordernumber));
		}
		if (StringUtils.isNotBlank(ponumber)) {
			filters.add(Filters.regex("po_number", ponumber));
		}
		System.out.println("Assignee::"+assignee);
		if (StringUtils.isNotBlank(assignee)) {
			System.out.println("Assignee::"+assignee);
			filters.add(Filters.regex("order_assignee", assignee));
		}
		
		if (StringUtils.isNotBlank(creationdatefrom) && StringUtils.isNotBlank(creationdateto)) {
			filters.add(new BasicDBObject("order_date",
					new BasicDBObject("$gte", creationdatefrom)
							.append("$lt", creationdateto)));
		}
	if (StringUtils.isNotBlank(requestedshipdatefrom) && StringUtils.isNotBlank(requestedshipdateto)) {
			filters.add(new BasicDBObject("requested_ship_date",
					new BasicDBObject("$gte", requestedshipdatefrom)
							.append("$lt", requestedshipdateto)));
		}
		if (StringUtils.isNotBlank(expectedshipdatefrom) && StringUtils.isNotBlank(expectedshipdateto)) {
			filters.add(new BasicDBObject("expected_ship_date",
					new BasicDBObject("$gte", expectedshipdatefrom)
							.append("$lt", expectedshipdateto)));
		}
		if (StringUtils.isNotBlank(confirmedshipdatefrom) && StringUtils.isNotBlank(confirmedshipdateto)) {
			filters.add(new BasicDBObject("confirmed_ship_date",
					new BasicDBObject("$gte", confirmedshipdatefrom)
							.append("$lt", confirmedshipdateto)));
		}
		if (StringUtils.isNotBlank(actualshipdatefrom) && StringUtils.isNotBlank(actualshipdateto)) {
			filters.add(new BasicDBObject("actual_ship_date",
					new BasicDBObject("$gte", actualshipdatefrom)
							.append("$lt", actualshipdateto)));
		}
		if (StringUtils.isNotBlank(orderstatus)) {
			filters.add(Filters.regex("order_status", orderstatus));
		}
		if (StringUtils.isNotBlank(customeruser)) {
			filters.add(Filters.regex("customer_user", customeruser));
		}
			
		Bson filter = filters.size() > 0 ? Filters.and(filters) : new Document();
		JSONArray array = new JSONArray();
		System.out.println("Display Filter ::"+filter);
		collection.find(filter).forEach(new Block<Document>() {
			@Override
			public void apply(Document orderDoc) {
				System.out.println("Printing OrderDoc::"+orderDoc.toString());
				JSONObject orderJson = new JSONObject(orderDoc.toJson());
				System.out.println("Printing _ID::"+orderJson.getString("_id"));
				String id = orderJson.getString("_id");
				orderJson.remove("_id");
				orderJson.put("id", id);
				array.put(orderJson);
				System.out.println("Printing OrderJSON ::"+orderJson);
			}
		});
		return array;

}
		
		public void updateOrder(JSONObject orderJson) {
			Bson filter = Filters.eq("_id", orderJson.getString("id"));
			Document orderDoc = Document.parse(orderJson.toString());
			String id = orderDoc.getString("id");
			orderDoc.remove("id");
			orderDoc.put("_id", id);
			collection.replaceOne(filter, orderDoc);
		}
}
