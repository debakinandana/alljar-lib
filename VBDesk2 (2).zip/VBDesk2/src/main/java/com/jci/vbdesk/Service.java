package com.jci.vbdesk;



import org.json.JSONArray;
import org.json.JSONObject;

import com.jci.vbdesk.model.Order;

public class Service {
	private static Service instance = new Service();
	
	
	public static Service getInstance() {
		return instance;
	}

	private Database database = Database.getInstance();

	public Service() {
	}
	
	/*public JSONArray getOrderByFilters(String customernumber, String ordernumber, String ponumber, String assignee,
			String creationdatefrom, String creationdateto,
			String requesteddelivdatefrom, String requesteddelivdateto,
			String expecteddelivdatefrom, String expecteddelivdateto,
			String confirmeddelivdatefrom, String confirmeddelivdateto,
			String actualdelivdatefrom, String actualdelivdateto,
			String orderstatus, String customeruser) {
		Order orders = new Order();
		return database.getOrderByFilters(orders.getCustomername(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
				orders.getCreationdateto(), orders.getRequesteddelivdatefrom(), orders.getRequesteddelivdateto(),
				orders.getExpecteddelivdatefrom(), orders.getExpecteddelivdateto(),
				orders.getConfirmeddelivdatefrom(), orders.getConfirmeddelivdateto(),
				orders.getActualdelivdatefrom(), orders.getActualdelivdateto(),
				orders.getOrderstatus(), orders.getCustomeruser());
	}*/
	
	public JSONObject getOrder(String id) {
		return database.getOrder(id);
	}
	
	public JSONObject saveOrder(JSONObject order) {
		database.updateOrder(order);
		return getOrder(order.getString("id"));
	}

	
}