package com.jci.vbdesk.model;

import java.math.BigDecimal;
import java.util.Date;

public class Order {
	
	
	int numberoflines;
	
	String ponumber;
	String customername;
	String ordernumber;
	String assignee;
	String orderstatus;
	String acceptsplitorder;
	String createdby;
	String customeruser;

	BigDecimal totalamount;
	BigDecimal totaldiscount;
	
	String creationdatefrom;
	String creationdateto;

	String requestedshipdatefrom;
	String requestedshipdateto;
	String expectedshipdatefrom;
	String expectedshipdateto;
	String confirmedshipdatefrom;
	String confirmedshipdateto;
	String actualshipdatefrom;
	String actualshipdateto;

	String orderdate;
	String requesteddate;
	String requestedshipdate;
	String expectedshipdate;
	String confirmedshipdate;
	String actualshipdate;
	String createddate; 

	public String getCustomeruser() {
		return customeruser;
	}

	public void setCustomeruser(String customeruser) {
		this.customeruser = customeruser;
	}
	
	public String getRequestedshipdatefrom() {
		return requestedshipdatefrom;
	}

	public void setRequestedshipdatefrom(String requestedshipdatefrom) {
		this.requestedshipdatefrom = requestedshipdatefrom;
	}

	public String getRequestedshipdateto() {
		return requestedshipdateto;
	}

	public void setRequestedshipdateto(String requestedshipdateto) {
		this.requestedshipdateto = requestedshipdateto;
	}

	public String getExpectedshipdatefrom() {
		return expectedshipdatefrom;
	}

	public void setExpectedshipdatefrom(String expectedshipdatefrom) {
		this.expectedshipdatefrom = expectedshipdatefrom;
	}

	public String getExpectedshipdateto() {
		return expectedshipdateto;
	}

	public void setExpectedshipdateto(String expectedshipdateto) {
		this.expectedshipdateto = expectedshipdateto;
	}

	public String getConfirmedshipdatefrom() {
		return confirmedshipdatefrom;
	}

	public void setConfirmedshipdatefrom(String confirmedshipdatefrom) {
		this.confirmedshipdatefrom = confirmedshipdatefrom;
	}

	public String getConfirmedshipdateto() {
		return confirmedshipdateto;
	}

	public void setConfirmedshipdateto(String confirmedshipdateto) {
		this.confirmedshipdateto = confirmedshipdateto;
	}

	public String getActualshipdatefrom() {
		return actualshipdatefrom;
	}

	public void setActualshipdatefrom(String actualshipdatefrom) {
		this.actualshipdatefrom = actualshipdatefrom;
	}

	public String getActualshipdateto() {
		return actualshipdateto;
	}

	public void setActualshipdateto(String actualshipdateto) {
		this.actualshipdateto = actualshipdateto;
	}
	
	
	public String getCreationdatefrom() {
		return creationdatefrom;
	}

	public void setCreationdatefrom(String creationdatefrom) {
		this.creationdatefrom = creationdatefrom;
	}

	public String getCreationdateto() {
		return creationdateto;
	}

	public void setCreationdateto(String creationdateto) {
		this.creationdateto = creationdateto;
	}

	
	public String getPonumber() {
		return ponumber;
	}

	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}


	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

	public String getRequesteddate() {
		return requesteddate;
	}

	public void setRequesteddate(String requesteddate) {
		this.requesteddate = requesteddate;
	}

	public BigDecimal getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(BigDecimal totalamount) {
		this.totalamount = totalamount;
	}

	public BigDecimal getTotaldiscount() {
		return totaldiscount;
	}

	public void setTotaldiscount(BigDecimal totaldiscount) {
		this.totaldiscount = totaldiscount;
	}

	public int getNumberoflines() {
		return numberoflines;
	}

	public void setNumberoflines(int numberoflines) {
		this.numberoflines = numberoflines;
	}

	public String getRequestedshipdate() {
		return requestedshipdate;
	}

	public void setRequestedshipdate(String requestedshipdate) {
		this.requestedshipdate = requestedshipdate;
	}

	public String getExpectedshipdate() {
		return expectedshipdate;
	}

	public void setExpectedshipdate(String expectedshipdate) {
		this.expectedshipdate = expectedshipdate;
	}

	public String getConfirmedshipdate() {
		return confirmedshipdate;
	}

	public void setConfirmedshipdate(String confirmedshipdate) {
		this.confirmedshipdate = confirmedshipdate;
	}

	public String getActualshipdate() {
		return actualshipdate;
	}

	public void setActualshipdate(String actualshipdate) {
		this.actualshipdate = actualshipdate;
	}

	public String getAcceptsplitorder() {
		return acceptsplitorder;
	}

	public void setAcceptsplitorder(String acceptsplitorder) {
		this.acceptsplitorder = acceptsplitorder;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getCreateddate() {
		return createddate;
	}

	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}

	public String getOrderstatus() {
		return orderstatus;
	}

	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}

	public String getOrdernumber() {
		return ordernumber;
	}

	public void setOrdernumber(String ordernumber) {
		this.ordernumber = ordernumber;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

}
