package com.jci.vbdesk.api;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jci.vbdesk.Service;

/*import com.jci.vbdesk.ServiceImpl;*/
import com.jci.vbdesk.model.Order;

import com.jci.vbdesk.Database;

@WebServlet(urlPatterns = "/api/search_orders")
public class SearchOrdersServlet extends HttpServlet {
	private Logger logger = Logger.getLogger(getClass().getName());

	//private Service service = Service.getInstance();

	private Database db = Database.getInstance();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
Order orders = new Order();
		
		/*DateFormat format = new SimpleDateFormat("EEE MMM dd hh:mm:ss Z yyyy", Locale.ENGLISH);*/
		//DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		JSONObject response = new JSONObject();
		
		System.out.println("SearchServlet call"+req.getParameter("firstcall"));

	
			/*JSONObject order = new JSONObject(req.getParameter("item"));*/
			//logger.log(Level.INFO,"Customer Number from Order JS:::::"+order.getString("customer_number"));
			
			//int ordernumber = Integer.parseInt(order.getString("order_number"));
			//String customernumber = order.getString("customer_number");
		
			System.out.println("CustomerName::"+req.getParameter("customer_name"));
			
			orders.setCustomername(req.getParameter("customer_name"));
			orders.setOrdernumber(req.getParameter("order_number"));
			orders.setPonumber(req.getParameter("po_number"));
			orders.setAssignee(req.getParameter("order_assignee"));
			
			orders.setCreationdatefrom(req.getParameter("creation_date_from"));
			orders.setCreationdateto(req.getParameter("creation_date_to"));
			orders.setRequestedshipdatefrom(req.getParameter("requested_ship_date_from"));
			orders.setRequestedshipdateto(req.getParameter("requested_ship_date_to"));
			orders.setExpectedshipdatefrom(req.getParameter("expected_ship_date_from"));
			orders.setExpectedshipdateto(req.getParameter("expected_ship_date_to"));
			orders.setConfirmedshipdatefrom(req.getParameter("confirmed_ship_date_from"));
			orders.setConfirmedshipdateto(req.getParameter("confirmed_ship_date_to"));
			orders.setActualshipdatefrom(req.getParameter("actual_ship_date_from"));
			orders.setActualshipdateto(req.getParameter("actual_ship_date_to"));
			
			orders.setOrderstatus(req.getParameter("order_status"));
			
			orders.setCustomeruser(req.getParameter("customer_user"));
		
			try {
	/*		Object result = service.getOrderByFilters(orders.getCustomernumber(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
					orders.getCreationdateto(), orders.getRequesteddelivdatefrom(), orders.getRequesteddelivdateto(),
					orders.getExpecteddelivdatefrom(), orders.getExpecteddelivdateto(),
					orders.getConfirmeddelivdatefrom(), orders.getConfirmeddelivdateto(),
					orders.getActualdelivdatefrom(), orders.getActualdelivdateto(),
					orders.getOrderstatus(), orders.getCustomeruser());*/
			
			Object result = db.getOrderByFilters(orders.getCustomername(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
					orders.getCreationdateto(), orders.getRequestedshipdatefrom(), orders.getRequestedshipdateto(),
					orders.getExpectedshipdatefrom(), orders.getExpectedshipdateto(),
					orders.getConfirmedshipdatefrom(), orders.getConfirmedshipdateto(),
					orders.getActualshipdatefrom(), orders.getActualshipdateto(),
					orders.getOrderstatus(), orders.getCustomeruser());

			System.out.println(":::::::::"+result.toString());
			response.put("result", result != null ? result : JSONObject.NULL);
						
			
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
			response.put("error", e.getMessage());
		
		}
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		/*Order orders = new Order();
		
		DateFormat format = new SimpleDateFormat("EEE MMM dd hh:mm:ss Z yyyy", Locale.ENGLISH);
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		JSONObject response = new JSONObject();
		
		System.out.println("SearchServlet call"+req.getParameter("firstcall"));

	
			JSONObject order = new JSONObject(req.getParameter("item"));
			//logger.log(Level.INFO,"Customer Number from Order JS:::::"+order.getString("customer_number"));
			
			//int ordernumber = Integer.parseInt(order.getString("order_number"));
			//String customernumber = order.getString("customer_number");
			
			orders.setCustomernumber(req.getParameter("customer_number"));
			orders.setOrdernumber(req.getParameter("order_number"));
			orders.setPonumber(req.getParameter("customer_po"));
			orders.setAssignee(req.getParameter("orders_assigned_to"));
			
			orders.setCreationdatefrom(req.getParameter("creation_date_from"));
			orders.setCreationdateto(req.getParameter("creation_date_to"));
			orders.setRequesteddelivdatefrom(req.getParameter("requested_delivery_date_from"));
			orders.setRequesteddelivdateto(req.getParameter("requested_delivery_date_to"));
			orders.setExpecteddelivdatefrom(req.getParameter("expected_delivery_date_from"));
			orders.setExpecteddelivdateto(req.getParameter("expected_delivery_date_to"));
			orders.setConfirmeddelivdatefrom(req.getParameter("confirmed_delivery_date_from"));
			orders.setConfirmeddelivdateto(req.getParameter("confirmed_delivery_date_to"));
			orders.setActualdelivdatefrom(req.getParameter("actual_delivery_date_from"));
			orders.setActualdelivdateto(req.getParameter("actual_delivery_date_to"));
			
			orders.setOrderstatus(req.getParameter("order_status"));
			orders.setCustomeruser(req.getParameter("customer_user"));
		
			try {
			Object result = service.getOrderByFilters(orders.getCustomernumber(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
					orders.getCreationdateto(), orders.getRequesteddelivdatefrom(), orders.getRequesteddelivdateto(),
					orders.getExpecteddelivdatefrom(), orders.getExpecteddelivdateto(),
					orders.getConfirmeddelivdatefrom(), orders.getConfirmeddelivdateto(),
					orders.getActualdelivdatefrom(), orders.getActualdelivdateto(),
					orders.getOrderstatus(), orders.getCustomeruser());
			
			Object result = db.getOrderByFilters(orders.getCustomernumber(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
					orders.getCreationdateto(), orders.getRequesteddelivdatefrom(), orders.getRequesteddelivdateto(),
					orders.getExpecteddelivdatefrom(), orders.getExpecteddelivdateto(),
					orders.getConfirmeddelivdatefrom(), orders.getConfirmeddelivdateto(),
					orders.getActualdelivdatefrom(), orders.getActualdelivdateto(),
					orders.getOrderstatus(), orders.getCustomeruser());

			System.out.println(":::::::::"+result.toString());
			response.put("result", result != null ? result : JSONObject.NULL);
						
			
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
		
		}
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	*/
	}
}
