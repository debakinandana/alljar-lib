package com.jci.vbdesk.api;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jci.vbdesk.Database;
import com.jci.vbdesk.Service;

@WebServlet(urlPatterns = "/api/save_order")
public class SaveOrderServlet extends HttpServlet {
	private Logger logger = Logger.getLogger(getClass().getName());

	private Service service = Service.getInstance();
	
	private Database db = Database.getInstance();

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject response = new JSONObject();

		try {
			logger.log(Level.INFO,"Save Servlet is called");
			JSONObject order = new JSONObject(req.getParameter("item"));
			
			logger.log(Level.INFO,"Save Servlet is processing"+req.getParameter("item"));
			logger.log(Level.INFO,order.getString("order_number"));
			Object result = service.saveOrder(order);
     		response.put("result", result != null ? result : JSONObject.NULL);
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
			response.put("error", e.getMessage());
		}

		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
