/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';

class Example extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}
	render() {
		return (
			<div>Example</div>
		);
	}
}

export default Example;
