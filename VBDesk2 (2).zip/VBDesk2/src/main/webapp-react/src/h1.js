/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import './h1.css';

class H1 extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (<h1 className="h1">{ this.props.title }</h1>);
	}
}

export default H1;
