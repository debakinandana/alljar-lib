/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import './header.css';

class Header extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (
			<div className="header row">
				<div className="col-xs-6 col-sm-6">
					<a href="#" onClick={ (e) => e.preventDefault() }><img src="img/jci.png" className="header" /></a>
				</div>
			</div>
		);
	}
}

export default Header;
