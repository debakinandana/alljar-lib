/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import Moment from 'react-moment';
import 'moment-timezone';
import uuidv4 from 'uuid/v4';


class Orders extends React.Component {
	constructor(props) {
		super(props);
		this.close = this.close.bind(this);
		this.create = this.create.bind(this);
		this.open = this.open.bind(this);
		this.save = this.save.bind(this);
		this.search = this.search.bind(this);
		this.firstcall=1;
		this.search({});
	}

	close() {
		this.search({});
	}

	create() {
		
		ajax({
			url: 'api/create_order',
			method: 'POST',
			data: {
			}
		}, (data) => {
			if (data.error == null) {
				this.search({});
			} else {
				alert(data.error);
			}
		});
	}

	open(id) {
		
		ajax({
			url: 'api/get_order',
			method: 'GET',
			data: {
				id: id
			}
		}, (data) => {
			if (data.error == null) {
				this.setState({ view: 'Details', item: data.result });
			} else {
				alert(data.error);
			}
		});
	}

	save(item) {
		
		ajax({
			url: 'api/save_order',
			method: 'POST',
			data: {
				item: JSON.stringify(item)
			}
		}, (data) => {
			if (data.error == null) {
				this.search({});
			} else {
				alert(data.error);
			}
		});
	}
	
	search(data) {
		this.state  = { view: 'Search', results: [] };
		console.log(this.state);
		if(this.firstcall!=1){
			
		ajax({
			url: 'api/search_orders?firstcall='+this.firstcall,
			method: 'GET',
			data: data
			}, (data) => {
				if (data.error == null) {
					this.setState({ results: data.result });
										
				}else {
					
					alert(data.error);
				}
				
			});
		if(data.result == null){
			alert.message('invalid Search');
		}
		}
		this.firstcall = this.firstcall+1;
	}
	
	render() {
		if (this.state.view == 'Search') return (<div><SearchForm  search={ this.search }  /><SearchResults results={ this.state.results } open={ this.open } /></div>);
		if (this.state.view == 'Details') return (<Details item={ this.state.item } close={ this.close } save={ this.save } />);
	
	}
}

class SearchForm extends React.Component {
	constructor(props) {
		super(props);
		this.handleCreate = this.handleCreate.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSearch = this.handleSearch.bind(this);
		this.orders_assigned_to= this.orders_assigned_to.bind(this);
		this.orders_status=this.orders_status.bind(this);
		this.state = { };
	}

	handleCreate(e) {
		e.preventDefault();
		this.props.create();
	}

	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		this.setState({ [name]: value });
	}
	
	handleClear() {
		this.refs.inputTitle.value="";
		this.refs.inputEntry.value="";
		this.refs.someName.value = '';
		}
	
	validateEmail(value) {
	    var re = null;
	    return re.test(value);
	    alert('!Required')
	  }
	
	orders_assigned_to(event) {
	    this.setState({orders_assigned_to: event.target.value});
	  }
	orders_status(event) {
		this.setState({order_status: event.target.value});
	}
	

	handleSearch(e) {
			e.preventDefault();
			this.props.search(this.state);
	}
	
	

	render() {
		const startDate = new Date();
	
		return (
		        

				<form className="form-horizontal">
				<div className="form-group">
					<label for="customer_name" className="col-sm-2 control-label" validations={['required']}>Customer Name</label>
					<div className="col-sm-3">
					<input name="customer_name"  type="text" value={ this.state.customer_name } className="form-control" onChange={ this.handleInputChange } validations={['required']}/>
					</div>
				
					<label for="order_number" className="col-sm-2 control-label">Order Number</label>
					<div className="col-sm-3">
						<input name="order_number" id="order_number" type="text" value={ this.state.order_number } className="form-control" onChange={ this.handleInputChange } validations={['required']} />
					</div>
				</div>
				
				<div className="form-group">
					<label for="order_assignee" className="col-sm-2 control-label">Orders Assigned To</label>
					<div className="col-sm-3">
					<select name="order_assignee" value={this.state.order_assignee} onChange={this.order_assignee}   className="form-control" >
					<option value=""></option>
					<option value="Jim">Jim</option>
					<option value="Norman">Norman</option>
					<option value="Susan">Susan</option>
					<option value="Mary">Mary</option>
					<option value="Ann">Ann</option>
					<p>{this.state.order_assignee}</p>
					</select>
					</div>
					
					
					<label for="po_number" className="col-sm-2 control-label">Customer PO</label>
					<div className="col-sm-3">
					<input name="po_number" type="text" value={ this.state.po_number } className="form-control" onChange={ this.handleInputChange } />             
					</div>
				</div>
				
				<div className="form-group">
					<label for="creation_date_from" className="col-sm-2 control-label">Creation Date From</label>
					<div className="col-md-3">
					<input name="creation_date_from" type="date" value={ this.state.creation_date_from } className="form-control" onChange= { this.handleInputChange } />		
					</div>
			
					<label for="creation_date_to" className="col-sm-2 control-label">To</label>
					<div className="col-md-3">
					<input name="creation_date_to" type="date" value={ this.state.creation_date_to } min={ this.state.creation_date_from }
					className="form-control" onChange={ this.handleInputChange } />
					</div>
				</div>
 				
 				<div className="form-group">
 					<label for="requested_ship_date_from" className="col-sm-2 control-label">Requested Ship Date From</label>
 					<div className="col-md-3">
 					<input name="requested_ship_date_from" type="date" value={ this.state.requested_ship_date_from } 

className="form-control" onChange= { this.handleInputChange } />
 					</div>
				
 					<label for="requested_ship_date_to" className="col-sm-2 control-label">To</label>
 					<div className="col-md-3">
 					<input name="requested_ship_date_to" type="date" value={ this.state.requested_ship_date_to } min={ this.state.requested_ship_date_from }

className="form-control" onChange= { this.handleInputChange } />
 					</div>
				</div>
				
				<div className="form-group">
					<label for="expected_ship_date_from" className="col-sm-2 control-label">Expected Ship Date From</label>
					<div className="col-md-3">
					<input name="expected_ship_date_from" type="date" value={ this.state.expected_ship_date_from } 

className="form-control" onChange= { this.handleInputChange } />
					</div>
			
					<label for="expected_ship_date_to" className="col-sm-2 control-label">To</label>
					<div className="col-md-3">
					<input name="expected_ship_date_to" type="date" value={ this.state.expected_ship_date_to } min={ this.state.expected_ship_date_from }

className="form-control" onChange= { this.handleInputChange } />
					</div>
				</div>
				
				<div className="form-group">
					<label for="confirmed_ship_date_from" className="col-sm-2 control-label">Confirmed Ship Date From</label>
					<div className="col-md-3">
					<input name="confirmed_ship_date_from" type="date" value={ this.state.confirmed_ship_date_from } 

className="form-control" onChange= { this.handleInputChange } />
					</div>
		
					<label for="confirmed_ship_date_to" className="col-sm-2 control-label">To</label>
					<div className="col-md-3">
					<input name="confirmed_ship_date_to" type="date" value={ this.state.confirmed_ship_date_to } min={ this.state.confirmed_ship_date_from }

className="form-control" onChange= { this.handleInputChange } />
					</div>
				</div>
				
				<div className="form-group">
					<label for="actual_ship_date_from" className="col-sm-2 control-label">Actual ship Date From</label>
					<div className="col-md-3">
					<input name="actual_ship_date_from" type="date" value={ this.state.actual_ship_date_from } 

className="form-control" onChange= { this.handleInputChange } />
					</div>
	
					<label for="actual_ship_date_to" className="col-sm-2 control-label">To</label>
					<div className="col-md-3">
					<input name="actual_ship_date_to" type="date" value={ this.state.actual_ship_date_to } min={ this.state.actual_ship_date_from }
					
className="form-control" onChange= { this.handleInputChange } />
					</div>
				</div>
 				
				<div className="form-group">
					<label for="order_status" className="col-sm-2 control-label">Order Status</label>
					<div className="col-sm-3">
					<select name="order_status" value={ this.state.order_status } onChange={this.orders_status } className="form-control" >
					<option value=""></option>
					<option value="Open">Open</option>
					<option value="Confirmed">Confirmed</option>
					<option value="Waiting for Cust. Conf">Waiting for Cust. Conf</option>
					<option value="Not Acceptable">Not Acceptable</option>
					<option value="Canceled">Canceled</option>
					<option value="Ship Date Changed">Ship Date Changed</option>
					<option value="Ship Date Confirmed">Ship Date Confirmed</option>
					<option value="Shipped">Shipped</option>
					<option value="Deleted">Deleted</option>
					</select>
					</div>

					<label for="customer_user" className="col-sm-2 control-label">Customer User</label>
					<div className="col-md-3">
					<input name="customer_user" type="text" value={ this.state.customer_user } className="form-control" onChange= { this.handleInputChange } />
					</div>
				</div>
 			
 				
				<div className="form-group">
					<div className="col-sm-offset-10 col-sm-2">
						<div>
						    <button type="submit" className="btn btn-primary" onClick={ this.handleSearch }>Search</button>
						    { ' ' }
							<button type="submit" className="btn btn-default" onClick={ this.handleClear }>Reset</button>
							
							
						</div>
					</div>
				</div>
			</form>
		);
	}
}

class SearchResults extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (
				
			<table className="table table-bordered"  style={{
               minWidth: 200,
                margin: 10,
                padding: 10,
                fontSize: 12
               
              }} >
				<thead >
					<tr>
						<th>Order Number</th>
						<th>Customer Name</th>
						<th>Customer PO</th>
						<th>Assignee</th>
						<th>Order Status</th>
						<th>Order Date</th>
						<th>Requested Date</th>
						<th>Total Amount</th>
						<th>Total Discount%</th>
						<th>No. Of Lines</th>
						<th>Requested Ship Date</th>
						<th>Expected Ship Date</th>
						<th>Confirmed Ship Date</th>
						<th>Actual Ship Date</th>
						<th>Accept Split Order</th>
						<th>Created By</th>
						<th>Created When</th>
					</tr>
				</thead>
				<SearchResultsList items={ this.props.results } open={ this.props.open } />
			</table>
		);
	}
}

class SearchResultsList extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (<tbody>{ this.props.items.map((item) => <SearchResultsItem key={ item.id } item={ item } open={ this.props.open } />) }</tbody>);
	}
}

class SearchResultsItem extends React.Component {
	constructor(props) {
		super(props);
		this.handleOpen = this.handleOpen.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.test=this.test.bind(this);
		this.state = { };
	}
	
	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		this.setState({ [name]: value });
	}

	handleOpen(e) {
		e.preventDefault();
		this.props.open(this.props.item.id);
		
	}
	test(e){
		e.preventDefault();

	this.props.test(this.props.sum);
	console.log("this.props.item.TotalAmount")
	this.props.test(this.props.TotalAmount);
	console.log("sum");
	
		
	}
	render() {
		
		return (
			<tr onClick={ this.handleOpen } style={{fontsize: '8',cursor: 'pointer'}}>
				<td>{ this.props.item.order_number }</td>
				<td>{ this.props.item.customer_name }</td>
				<td>{ this.props.item.po_number }</td>
				<td>{ this.props.item.order_assignee }</td>
				<td>{ this.props.item.order_status }</td>
				<td> <Moment format="DD-MMM-YYYY">{ this.props.item.order_date }</Moment></td>
				<td> <Moment format="DD-MMM-YYYY">{ this.props.item.order_date }</Moment></td>
				<td>{ this.props.item.total_net_amount }</td>
				<td>{ this.props.item.discount_amount }</td>
				<td>{ this.props.item.NumberofLines }</td>
				<td> <Moment format="DD-MMM-YYYY">{ this.props.item.requested_ship_date }</Moment></td>
				<td><Moment format="DD-MMM-YYYY">{ this.props.item.expected_ship_date }</Moment></td>
				<td><Moment format="DD-MMM-YYYY">{ this.props.item.confirmed_ship_date }</Moment></td>
				<td><Moment format="DD-MMM-YYYY">{ this.props.item.actual_ship_date }</Moment></td>
				<td><input name="accept_split_order" type="checkbox" style={{width: '20'}}checked={this.props.item.accept_split_order=="true" ?'true':''} className="form-control" /></td>
				<td>{ this.props.item.buyer_email }</td>
				<td><Moment format="DD-MMM-YYYY">{ this.props.item.order_date }</Moment></td>
				
			</tr>
		);
	}
}

class Details extends React.Component {
	constructor(props) {
		super(props);
		this.removeLine = this.removeLine.bind(this);
		this.handleAddLine = this.handleAddLine.bind(this);
		this.handleClose = this.handleClose.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSave = this.handleSave.bind(this);
		this.handleAction = this.handleAction.bind(this);
		this.state = { disabled: false };
		
		this.state = { item: props.item };
	}

	removeLine(id) {
		var item = this.state.item;
		var lines = item.order_lines;
		var sum=0;
		var total;
		var i = null;
		for (var j = 0; j < lines.length; j++) {
			if (lines[j].id == id) {
			
				 sum= lines[j].line_price;
			
				
				i=j;
			
			break;
			}
			}
			
		lines.splice(i, 1);
		this.setState({ item: item });
	}

	handleAddLine(e) {
		e.preventDefault();
		var item = this.state.item;
		var line = { id: uuidv4() };
		item.order_lines.push(line);
		this.setState({ item: item });
	}

	handleClose(e) {
		e.preventDefault();
		this.props.close();
	}

	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const item = this.state.item;
		item[name] = value;
		this.setState({ item: item });
	}

	handleSave(e) {
		e.preventDefault();
		this.props.save(this.state.item);
	}
	
	 handleAction(e) {
			this.setState({action:e.target.value});
			}
	 
	 handleGameClik() {
		    this.setState( {disabled: !this.state.disabled} )
	 } 
		    render() {
	
		return (
				<div>
				{this. handleGameClik()}
			
				</div>
			);	 	
	}
		  
	
	 readMode()
	 {
		 
		 if(this.state.action != "EditOrder") {
		 return (
		 <div>
			<form className="form-horizontal">
				<div className="row">
					<div className="col-sm-12">
					
					<div className="form-group">
					<label for="action" className="col-sm-2 control-label">Action :</label>
					<div className="col-sm-3">
					
					<button  value={this.state.item.action} onChange={this.handleAction} className="form-control" >
					<option value=""></option>
					<option value="PrintOrder">PrintOrder</option>
					<option value="DeleteOrder">DeleteOrder</option>
					<option value="DuplicateOrder">DuplicateOrder</option>
					<option value="ViewChangeLog">ViewChangeLog</option>
					<option value="EditOrder">EditOrder</option>
					<option value="PrintInvoice">PrintInvoice</option>
					<option value="Publish">Publish</option>
					</select>
					</div>
					</div>
					<div className="form-group">
					
							<label for="customer_name" className="col-sm-2 control-label">Customer Name</label>
							<div className="col-sm-3">
								<input name="customer_name" type="text" readOnly="true" value={ this.state.item.customer_name } className="form-control" onChange={ this.handleInputChange } />  
								
							</div>
							<label for="order_number" className="col-sm-2 control-label">Order Number</label>
							<div className="col-sm-3">
								<input name="order_number" type="text" readOnly="true"  value={ this.state.item.order_number }  className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="order_assignee" className="col-sm-2 control-label">Orders Assigned To</label>
							<div className="col-sm-3">
								<input name="order_assignee" type="text" readOnly="true"  value={ this.state.item.order_assignee } className="form-control" onChange={ this.handleInputChange } />
							
							</div>
							<label for="po_number" className="col-sm-2 control-label">Customer PO</label>
							<div className="col-sm-3">
							<input name="po_number" type="text" readOnly="true"  value={ this.state.item.po_number } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="total_net_amount" className="col-sm-2 control-label">Total Amount</label>
							<div className="col-sm-3">
							<input name="total_net_amount" type="text" readOnly="true"  value={ this.state.item.total_net_amount } className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="discount_amount" className="col-sm-2 control-label">Total Discount</label>
							<div className="col-sm-3">
							<input name="discount_amount" type="text" readOnly="true"  value={ this.state.item.discount_amount } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="requested_ship_date" className="col-sm-2 control-label">Requested Ship Date</label>
							<div className="col-sm-3">
								<input name="requested_ship_date" type="date" readOnly="true"  value={ this.state.item.requested_ship_date } className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="order_status" className="col-sm-2 control-label">Order Status</label>
							<div className="col-sm-3">
							<input name="order_status" type="text" readOnly="true"  value={ this.state.item.order_status } className="form-control" onChange={ this.handleInputChange } />

							</div>
						</div>
						<div className="form-group">
							<label for="internal_note" className="col-sm-2 control-label">Internal Notes</label>
							<div className="col-sm-3">
								<textarea name="internal_note" readOnly="true"  type="text" value={ this.state.item.internal_note } className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="customer_note" className="col-sm-2 control-label">Customer Notes</label>
							<div className="col-sm-3">
								<textarea name="customer_note" readOnly="true"  type="text" value={ this.state.item.customer_note } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
						<label for="attachdocuments" className="col-sm-2 control-label">Attach Documents to Order </label>
						<div className="col-sm-3">
							<input name="attachdocuments"  type="file" value={ this.state.item.attachdocuments } className="file"  />
								
						</div>
						</div>
						<div className="form-group">
							<label for="BilltoAddress" className="col-sm-2 control-label">Bill To Address </label>
							<div className="col-sm-3">
								<input name="bill_to_address_name" readOnly="true"  type="text" value={ this.state.item.bill_to_address_name } className="form-control" onChange={ this.handleInputChange } />
								<input name="bill_to_address_company" readOnly="true"  type="text" value={ this.state.item.bill_to_address_company } className="form-control" onChange={ this.handleInputChange } />
								<input name="bill_to_address_city" readOnly="true"  type="text" value={ this.state.item.bill_to_address_city } className="form-control" onChange={ this.handleInputChange } />
								<input name="bill_to_address_address" readOnly="true"  type="text" value={ this.state.item.bill_to_address_address } className="form-control" onChange={ this.handleInputChange } />
								<input name="bill_to_address_country" readOnly="true"  type="text" value={ this.state.item.bill_to_address_country } className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ShiptoAddress" className="col-sm-2 control-label">Ship To Address</label>
							<div className="col-sm-3">
								<input name="ship_to_address_name" readOnly="true"  type="text" value={ this.state.item.ship_to_address_name } className="form-control" onChange={ this.handleInputChange } />
								<input name="ship_to_address_company" readOnly="true"  type="text" value={ this.state.item.ship_to_address_company } className="form-control" onChange={ this.handleInputChange } />
								<input name="ship_to_address_address" readOnly="true"  type="text" value={ this.state.item.ship_to_address_address } className="form-control" onChange={ this.handleInputChange } />
								<input name="ship_to_address_city" readOnly="true"  type="text" value={ this.state.item.ship_to_address_city } className="form-control" onChange={ this.handleInputChange } />
								<input name="ship_to_address_country" readOnly="true"  type="text" value={ this.state.item.ship_to_address_country } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="PaymentTerms" className="col-sm-2 control-label">Payment Terms</label>
							<div className="col-sm-3">
								<select name="PaymentTerms" readOnly="true"  value={ this.state.PaymentTerms } className="form-control" >
								<option value=""></option>
								</select>
							</div>
							<label for="order_date" className="col-sm-2 control-label">Order Date</label>
							<div className="col-sm-3">
								<input name="order_date" readOnly="true"  type="date" value={ this.state.item.order_date } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
						<label for="note_to_customer" className="col-sm-2 control-label">Notes To Customer</label>
						<div className="col-sm-3">
							<textarea name="note_to_customer"  readOnly="true" type="text" value={ this.state.item.note_to_customer } className="form-control" onChange={ this.handleInputChange } />
						</div>
						<label for="actual_ship_date"  className="col-sm-2 control-label">Ship Date</label>
						<div className="col-sm-3">
							<input name="actual_ship_date" readOnly="true" type="date" value={ this.state.item.actual_ship_date } className="form-control" onChange={ this.handleInputChange } />
						</div>
					</div>
						<div className="form-group">
							<div className="col-sm-offset-4 col-sm-8">
								<button type="submit" className="btn btn-primary" onClick={ this.handleSave }>Save</button>
								{ ' ' }
								<button type="submit" className="btn btn-default" onClick={ this.handleClose }>Cancel</button>
							</div>
						</div>
					</div>
					</div>
				<table className="table table-bordered" style={{fontsize: '10'}}>
					<thead>
						<tr>
							<th>Line Number</th>
							<th>Product Code</th>
							<th>Description</th>
							<th>Quantity</th>
							<th>Ship Date</th>
							<th>Unit Price</th>
							<th>Total Price</th>
							<th>Action(s)</th>
						</tr>
					</thead>
					<DetailsList items={ this.state.item.order_lines } removeLine={ this.removeLine } />
					<tfoot>
						<tr>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><input type="text" className="form-control" disabled="disabled" /></th>
							<th><button type="submit" className="btn btn-default" style={{size: '10'}} onClick={ this.handleAddLine }><span style={{size: '10'}} className="glyphicon glyphicon-plus"></span></button></th>
						</tr>
					</tfoot>
				</table>
			</form>
		</div>
	);
		 }
		 else
			 {
			 return (
					 <div>
						<form className="form-horizontal">
							<div className="row">
								<div className="col-sm-12">
								<div className="form-group">
								<label for="action" className="col-sm-2 control-label">Action :</label>
								<div className="col-sm-3">
								<select name="action" value={this.state.item.action} onChange={this.handleAction} className="form-control" >
								<option value=""></option>
								<option value="PrintOrder">PrintOrder</option>
								<option value="DeleteOrder">DeleteOrder</option>
								<option value="DuplicateOrder">DuplicateOrder</option>
								<option value="ViewChangeLog">ViewChangeLog</option>
								<option value="EditOrder">EditOrder</option>
								<option value="PrintInvoice">PrintInvoice</option>
								<option value="Publish">Publish</option>
								</select>
							</div>
								</div>
								<div className="form-group">
								
										
										<label for="customer_name" className="col-sm-2 control-label">Customer Name</label>
										<div className="col-sm-3">
												<input name="customer_name" type="text"  value={ this.state.item.customer_name } className="form-control" onChange={ this.handleInputChange } />  
																
										</div>
										<label for="order_number" className="col-sm-2 control-label">Order Number</label>
										<div className="col-sm-3">
											<input name="order_number" type="text"   value={ this.state.item.order_number } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
										<label for="order_assignee" className="col-sm-2 control-label">Orders Assigned To</label>
										<div className="col-sm-3">
										<select name="order_assignee" value={ this.state.order_assignee } onChange={this.handleInputChange} className="form-control" >
										<option value=""></option>
										<option value="Jim">Jim</option>
										<option value="Norman">Norman</option>
										<option value="Susan">Susan</option>
										<option value="Mary">Mary</option>
										<option value="Ann">Ann</option>
										</select>
										
										</div>
										<label for="po_number" className="col-sm-2 control-label">Customer PO</label>
										<div className="col-sm-3">
										<input name="po_number" type="text"  value={ this.state.item.po_number } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
										<label for="total_net_amount" className="col-sm-2 control-label">Total Amount</label>
										<div className="col-sm-3">
										<input name="total_net_amount" type="text"  value={ this.state.item.total_net_amount } className="form-control" onChange={ this.handleInputChange } />
										</div>
										<label for="discount_amount" className="col-sm-2 control-label">Total Discount</label>
										<div className="col-sm-3">
										<input name="discount_amount" type="text"   value={ this.state.item.discount_amount } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
										<label for="requested_ship_date" readOnly="true" className="col-sm-2 control-label">Requested Ship Date</label>
										<div className="col-sm-3">
											<input name="requested_ship_date" type="date"  value={ this.state.item.requested_ship_date } className="form-control" onChange={ this.handleInputChange } />
										</div>
										<label for="order_status" className="col-sm-2 control-label">Order Status</label>
										<div className="col-sm-3">
										<select name="order_status" value={ this.state.order_status } className="form-control" >
										<option value=""></option>
										<option value="Open">Open</option>
										<option value="Confirmed">Confirmed</option>
										<option value="Waiting for Cust. Conf">Waiting for Cust. Conf</option>
										<option value="Not Acceptable">Not Acceptable</option>
										<option value="Canceled">Canceled</option>
										<option value="Ship Date Changed">Ship Date Changed</option>
										<option value="Ship Date Confirmed">Ship Date Confirmed</option>
										<option value="Shipped">Shipped</option>
										<option value="Deleted">Deleted</option>
										</select>
										</div>
									</div>
									<div className="form-group">
										<label for="internal_note" className="col-sm-2 control-label">Internal Notes</label>
										<div className="col-sm-3">
											<textarea name="internal_note"   type="text" value={ this.state.item.internal_note } className="form-control" onChange={ this.handleInputChange } />
										</div>
										<label for="customer_note"  className="col-sm-2 control-label">Customer Notes</label>
										<div className="col-sm-3">
											<textarea name="customer_note"  type="text" value={ this.state.item.customer_note } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
									<label for="attachdocuments" className="col-sm-2 control-label">Attach Documents to Order </label>
									<div className="col-sm-3">
										<input name="attachdocuments"  type="file" value={ this.state.item.attachdocuments } class="file"  />
											
									</div>
									</div>
									<div className="form-group">
										<label for="BilltoAddress" className="col-sm-2 control-label">Bill To Address </label>
										<div className="col-sm-3">
											<input name="bill_to_address_name"   type="text" value={ this.state.item.bill_to_address_name } className="form-control" onChange={ this.handleInputChange } />
											<input name="bill_to_address_company"   type="text" value={ this.state.item.bill_to_address_company } className="form-control" onChange={ this.handleInputChange } />
											<input name="bill_to_address_address"   type="text" value={ this.state.item.bill_to_address_address } className="form-control" onChange={ this.handleInputChange } />
											<input name="bill_to_address_city"   type="text" value={ this.state.item.bill_to_address_city } className="form-control" onChange={ this.handleInputChange } />
											<input name="bill_to_address_country"  type="text" value={ this.state.item.bill_to_address_country } className="form-control" onChange={ this.handleInputChange } />
											
										</div>
										<label for="ShiptoAddress" className="col-sm-2 control-label">Ship To Address</label>
										<div className="col-sm-3">
											<input name="ship_to_address_name"   type="text" value={ this.state.item.ship_to_address_name } className="form-control" onChange={ this.handleInputChange } />
											<input name="ship_to_address_company"   type="text" value={ this.state.item.ship_to_address_company } className="form-control" onChange={ this.handleInputChange } />
											<input name="ship_to_address_address"   type="text" value={ this.state.item.ship_to_address_address } className="form-control" onChange={ this.handleInputChange } />
											<input name="ship_to_address_city"   type="text" value={ this.state.item.ship_to_address_city } className="form-control" onChange={ this.handleInputChange } />
											<input name="ship_to_address_country"  type="text" value={ this.state.item.ship_to_address_country } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
										<label for="PaymentTerms" className="col-sm-2 control-label">Payment Terms</label>
										<div className="col-sm-3">
											<select name="PaymentTerms"   value={ this.state.PaymentTerms } className="form-control" >
											<option value="PaymentTerm1">PaymentTerm1</option>
											<option value="PaymentTerm2">PaymentTerm2</option>
											<option value="PaymentTerm3">PaymentTerm3</option>
											<option value="PaymentTerm4">PaymentTerm4</option>
											</select>
										</div>
										<label for="order_date" className="col-sm-2 control-label">Order Date</label>
										<div className="col-sm-3">
											<input name="order_date"  type="date" value={ this.state.item.order_date } className="form-control" onChange={ this.handleInputChange } />
										</div>
									</div>
									<div className="form-group">
									<label for="note_to_customer" className="col-sm-2 control-label">Notes To Customer</label>
									<div className="col-sm-3">
										<textarea name="note_to_customer"   type="text" value={ this.state.item.note_to_customer } className="form-control" onChange={ this.handleInputChange } />
									</div>
									<label for="actual_ship_date"  className="col-sm-2 control-label">Ship Date</label>
									<div className="col-sm-3">
										<input name="actual_ship_date"  type="date" value={ this.state.item.actual_ship_date } className="form-control" onChange={ this.handleInputChange } />
									</div>
								</div>
								
									<div className="form-group">
										<div className="col-sm-offset-4 col-sm-8">
											<button type="submit" className="btn btn-primary" onClick={ this.handleSave }>Save</button>
											{ ' ' }
											<button type="submit" className="btn btn-default" onClick={ this.handleClose }>Cancel</button>
										</div>
									</div>
								</div>
							</div>
							<table className="table">
								<thead>
									<tr>
										<th>Line Number</th>
										<th>Product Code</th>
										<th>Description</th>
										<th>Quantity</th>
										<th>Ship Date</th>
										<th>Unit Price</th>
										<th>Total Price</th>
										<th>Action(s)</th>
									</tr>
								</thead>
								<DetailsList items={ this.state.item.order_lines } removeLine={ this.removeLine } />
								<tfoot>
									<tr>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><input type="text" className="form-control" disabled="disabled" /></th>
										<th><button type="submit" className="btn btn-default" style={{size: '10'}} onClick={ this.handleAddLine }><span	style={{size: '10'}} className="glyphicon glyphicon-plus"></span></button></th>
									</tr>
								</tfoot>
							</table>
						</form>
					</div>
				);
			
			 }
	 }

	
	 render() {
	
		return (
				<div>
				{this.readMode()}
			
				</div>
			);	 	
	}
}

class DetailsList extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (<tbody>{ this.props.items.map((item) => <DetailsItem key={ item.id } item={ item } removeLine={ this.props.removeLine } />) }

</tbody>);
	}
}

class DetailsItem extends React.Component {
	constructor(props) {
		super(props);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleRemoveLine = this.handleRemoveLine.bind(this);
		this.state = { item: props.item };
	}
	
	
	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;

		const item = this.state.item;
		item[name] = value;

		this.setState({ item: item });
	}

	handleRemoveLine(e) {
		e.preventDefault();
		this.props.removeLine(this.props.item.id);
	}
	
	
	render() {
		return (
			<tr>
				<td><input name="line_number" type="text" value={ this.state.item.line_number }  className="form-control" onChange={ this.handleInputChange }/> </td>
				<td><input name="product_code" type="text" value={ this.state.item.product_code }  className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="description" type="text" value={ this.state.item.description } className="form-control" onChange={ this.handleInputChange } /> </td>
				<td><input name="quantity" type="number" value={ this.state.item.quantity }  className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="requested_ship_date" type="date" value={ this.state.item.requested_ship_date }  className="form-control" onChange={ this.handleInputChange }  /></td>
				<td><input name="unit_price" type="number" value={ this.state.item.unit_price }  className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="line_price" type="number" value={ this.state.item.line_price } className="form-control" onChange={ this.handleInputChange } /></td>
				<td><button type="submit" className="btn btn-default" style={{size: '5'}} onClick={ this.handleRemoveLine }><span className="glyphicon glyphicon-minus style={{size: '5'}}"></span></button></td>
			</tr>
		);
	}
}

export default Orders;
