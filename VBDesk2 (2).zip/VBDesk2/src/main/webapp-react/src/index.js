/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React from 'react';
import ReactDOM from 'react-dom';


import App from './app';

import registerServiceWorker from './registerServiceWorker';

$(document).ready(function() {
	google.charts.load('current', { packages : [ 'corechart' ] });
	google.charts.setOnLoadCallback(function() {
		ReactDOM.render(<App view="Orders" />, document.getElementById('root'));
		registerServiceWorker();
	});
});
