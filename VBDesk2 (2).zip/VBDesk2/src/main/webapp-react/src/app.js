/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';

import Footer from './footer';
import H1 from './h1';
import Header from './header';
import Layout from './layout';
import Navigation from './navigation';

import Example from './example';
import Orders from './orders';

class App extends React.Component {
	constructor(props) {
		super(props);
		this.navigate = this.navigate.bind(this);
		this.state = { view: props.view };
	}

	navigate(v) {
		this.setState({ view: v });
	}

	render() {
		return (<Layout header={ <div><Header /><Navigation menu={ this.state.view } navigate={ this.navigate } /></div> }
			left={ <div><H1 title={ this.state.view } /></div> }
			center={ <div><AppCenter view={ this.state.view } /></div> }
			footer={ <Footer /> } />);
	}
}

class AppCenter extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		if (this.props.view == 'Orders') return (<Orders />);
		if (this.props.view == 'Example') return (<Example />);
	}
}

export default App;
