/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';

class Navigation extends React.Component {
	constructor(props) {
		super(props);
		this.navigate = this.navigate.bind(this);
		this.state = { };
	}

	navigate(menu) {
		this.props.navigate(menu);
	}

	render() {
		return (
			<div>
				<nav className="navbar navbar-inverse">
					<div className="container-fluid">
						<div className="navbar-header">
							<button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span className="sr-only">Toggle navigation</span>
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
								<span className="icon-bar"></span>
							</button>
							<a className="navbar-brand" href="#" onClick={ (e) => e.preventDefault() }>VB Desk</a>
						</div>
						<div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul className="nav navbar-nav">
								<NavigationItem active={ this.props.menu } navigate={ this.navigate } value="Orders" />" +
										<NavigationItem active={this.props.menu} navigate={this.navigate} value="Admin Page" />"+
								<NavigationItem active={ this.props.menu } navigate={ this.navigate } value="Example" />" +
									
							</ul>
						</div>
					</div>
				</nav>
			</div>
		);
	}
}

class NavigationItem extends React.Component {
	constructor(props) {
		super(props);
		this.click = this.click.bind(this);
		this.state = { };
	}

	click(e) {
		e.preventDefault();
		this.props.navigate(this.props.value);
	}

	render() {
		if (this.props.active == this.props.value) return (<li className="active"><a href="#" onClick={ this.click }>{ this.props.value } <span className="sr-only">(current)</span></a></li>);
		if (this.props.active != this.props.value) return (<li><a href="#" onClick={ this.click }>{ this.props.value }</a></li>);
	}
}

export default Navigation;
